package com.googleSearch.Tests;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.Test;

import com.pinki.selenium.FuntionalTests.SearchForChemtrailsPage;
import com.pinki.selenium.FuntionalTests.SearchForDealeyPlaza;
import com.pinki.selenium.FuntionalTests.SearchForGoogleMaps;

public class GoogleSearchTest extends FunctionalTest {

	@Test

	public void googleSearch() throws InterruptedException {

		driver.get("http://www.google.com");

		SearchForChemtrailsPage chemtrailsSearchPage = new SearchForChemtrailsPage(driver);

		assertTrue(chemtrailsSearchPage.isInitialized());

		chemtrailsSearchPage.enterChemtrails("Chemtrails");

		SearchForDealeyPlaza dealeyPlazaSearchPage = new SearchForDealeyPlaza(driver);

		dealeyPlazaSearchPage.enterDealeyPlaza("Dealey Plaza");

		assertTrue(dealeyPlazaSearchPage.isInitialized());

		SearchForGoogleMaps googlehomePage = new SearchForGoogleMaps(driver);

		googlehomePage.enterGoogleHomepage("Google homepage");

		assertTrue(dealeyPlazaSearchPage.isInitialized());

	}

}
