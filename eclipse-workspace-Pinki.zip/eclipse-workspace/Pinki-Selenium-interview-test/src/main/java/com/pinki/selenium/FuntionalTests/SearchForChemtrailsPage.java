package com.pinki.selenium.FuntionalTests;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.testng.Assert;

public class SearchForChemtrailsPage extends PageObject {

	@FindBy(name = "q")
	private WebElement SearchgoogleInputbox;

//	@FindAll(value = { @FindBy(xpath = "//ul[@role='listbox']//li/descendant::div[@class='sbl1']") })
//	private List<WebElement> listOfElements;

//	@FindBys(@FindBy(xpath = "//ul[@role='listbox']//li/descendant::div[@class='sbl1']"))
//	private List<WebElement> listOfElements;

	@FindBy(xpath = "//ul[@role='listbox']//li/descendant::div[@class='sbl1']")
	private List<WebElement> listOfElements;

	public SearchForChemtrailsPage(WebDriver driver) {
		super(driver);

	}

	public boolean isInitialized() {

		return SearchgoogleInputbox.isDisplayed();

	}

	public void enterChemtrails(String SearchgoogleInputbox) throws InterruptedException {

		this.SearchgoogleInputbox.clear();

		this.SearchgoogleInputbox.click();

		this.SearchgoogleInputbox.sendKeys(SearchgoogleInputbox);

		Thread.sleep(10000);

		int numbers = listOfElements.size();

		System.out.println("Count of all items:-" +numbers);

		/**
		 * Code to verify the first text entry contains the word "Chemtrails"
		 */

		String listItem1 = listOfElements.get(0).getText();

		System.out.println(listItem1);

		Assert.assertTrue(listItem1.contains("chemtrails"));

		Thread.sleep(1000);

		System.out.println("*********Confirmed the first text entry contains the word \"Chemtrails\"**********");

	}

}
