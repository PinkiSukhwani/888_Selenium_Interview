package com.pinki.selenium.FuntionalTests;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

public class SearchForGoogleMaps extends PageObject {

	@FindBy(name = "q")
	private WebElement SearchgoogleInputbox;

	@FindBy(xpath = "//*[@id=\"hdtb-msb-vis\"]/div[4]/a")
	private WebElement googleMaps;

	@FindBy(xpath = "//*[@id=\"omnibox-singlebox\"]/div[1]/div[1]/button")
	private WebElement googleMapOptions;

	@FindBy(xpath = "//label[text() = 'Globe']")
	private WebElement globe;

	@FindBy(xpath = "//button[starts-with(@role,'menuitem')]")
	private List<WebElement> menuItems;

	public SearchForGoogleMaps(WebDriver driver) {
		super(driver);
	}

	public boolean isInitialized() {

		return SearchgoogleInputbox.isDisplayed();

	}

	public void enterGoogleHomepage(String SearchgoogleInputbox) throws InterruptedException {

		this.SearchgoogleInputbox.clear();

		this.SearchgoogleInputbox.sendKeys(SearchgoogleInputbox);

		Thread.sleep(10000);

		this.SearchgoogleInputbox.sendKeys(Keys.ENTER);

		this.googleMaps.click();

		Thread.sleep(5000);

		this.googleMapOptions.click();

		Thread.sleep(5000);

		/**
		 * Scenario one:- we will very the map view through color if the color of globe
		 * element is blue it would be globe view else flat earth view
		 */

		String actualGlobeColor = "#1a73e8";

		String globeColor = globe.getCssValue("color");
		System.out.println("Color of Globe is:-" + globeColor);

		// Use Color class to convert the value from rgba() to Hex code and store in a
		// variable
		String expectedGlobeColor = Color.fromString(globeColor).asHex();

		if (expectedGlobeColor == actualGlobeColor) {

			System.out.println("The Map view is the Globe view");
		} else {
			System.out.println("The Map view is the Flat Earth view");
		}

		// Verify if actual and expected color values are equal?
		Assert.assertEquals(expectedGlobeColor, actualGlobeColor);

		/**
		 * Scenario two:- It will iterate each and every element in google map options
		 * whether Google has provided an option named "Flat Earth View"
		 */

		for (WebElement element : menuItems) {
			System.out.println(element.getText());
			Assert.assertFalse(element.getText().equalsIgnoreCase("Flat Earth View"));
		}

		System.out.println("**************Google hasn't provided an option named \"Flat Earth View\"*****************");

//      Iterator<WebElement> iterateMenuItems = menuItems.iterator();

//		while (iterateMenuItems.hasNext()) {
//			WebElement we = iterateMenuItems.next();
//
//			if (we.equals("Flat Earth View")) {
//				
//				System.out.println("Google has provided an option named \"Flat Earth View\"");
//
//			} 
//			
//			else {
//
//				System.out.println("Google hasn't provided an option named \"Flat Earth View\"");
//
//			}
//
//			Assert.assertFalse(we.equals("Flat Earth View"), "Google has provided an option named Flat Earth View");
//
//		}

	}

}
