package com.pinki.selenium.FuntionalTests;

import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

public class SearchForDealeyPlaza extends PageObject {

	@FindBy(name = "q")
	private WebElement SearchgoogleInputbox;
	
	@FindBy(xpath = "//img[starts-with(@id,'dimg_')]")
	private List<WebElement> listOfimages;
	

	public SearchForDealeyPlaza(WebDriver driver) {
		super(driver);
	}

	public boolean isInitialized() {

		return SearchgoogleInputbox.isDisplayed();

	}

	public void enterDealeyPlaza(String SearchgoogleInputbox) throws InterruptedException {

		this.SearchgoogleInputbox.clear();

		this.SearchgoogleInputbox.sendKeys(SearchgoogleInputbox);
		
		Thread.sleep(5000);

		this.SearchgoogleInputbox.sendKeys(Keys.ENTER);
		
		Thread.sleep(1000);

		int numbers = listOfimages.size();

		System.out.println("Count of images present in the current page is:-" +numbers);

		/**
		 * Code to verify the first text entry contains the word "Chemtrails"
		 */

		String imageTitle = listOfimages.get(0).getAttribute("title");	

		System.out.println("Tilte of the first image:- " +imageTitle);

		Assert.assertTrue(imageTitle.contains("Dealey_Plaza"));

		Thread.sleep(5000);

		System.out.println("*********Confirm the first image title contains the phrase \"Dealey Plaza\"**********");

		Thread.sleep(5000);

	}

}
